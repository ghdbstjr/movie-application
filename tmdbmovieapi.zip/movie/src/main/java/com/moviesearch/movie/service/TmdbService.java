package com.moviesearch.movie.service;

import com.moviesearch.movie.dto.MovieSearchResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
public class TmdbService {

    private final RestTemplate restTemplate;

    @Value("${tmdb.api.key}")
    private String apiKey;

    public TmdbService() {
        this.restTemplate = new RestTemplate();
    }

    public MovieSearchResponse searchMovies(String query) {
        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);  // ✅ 표준 자바로 인코딩
        String url = String.format(
                "https://api.themoviedb.org/3/search/movie?api_key=%s&language=ko-KR&query=%s",
                apiKey, encodedQuery
        );
        return restTemplate.getForObject(url, MovieSearchResponse.class);
    }
}