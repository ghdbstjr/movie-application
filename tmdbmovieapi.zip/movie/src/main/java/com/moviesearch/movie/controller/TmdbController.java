package com.moviesearch.movie.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import com.moviesearch.movie.service.TmdbService;
import com.moviesearch.movie.dto.MovieSearchResponse;

@Tag(name = "TMDB 영화 검색 API", description = "TMDB 외부 API를 이용한 영화 검색 기능")
@RestController
@RequestMapping("/tmdb")
public class TmdbController {

    private final TmdbService tmdbService;

    public TmdbController(TmdbService tmdbService) {
        this.tmdbService = tmdbService;
    }

    @Operation(summary = "영화 제목 검색", description = "제목 키워드를 입력하면 TMDB에서 영화 목록을 반환.")
    @GetMapping("/search")
    public ResponseEntity<MovieSearchResponse> searchMovie(@RequestParam String query) {
        return ResponseEntity.ok(tmdbService.searchMovies(query));
    }
}