document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('search-button');
    const searchInput = document.getElementById('search-input');
    const resultDiv = document.getElementById('search-result');

    let movies = [];
    let currentPage = 1;
    const itemsPerPage = 4;

    if (searchButton) {
      searchButton.addEventListener('click', async () => {
        const query = searchInput.value.trim();
        if (!query) {
          alert('검색어를 입력하세요!');
          return;
        }

        try {
          const response = await fetch(`/tmdb/search?query=${encodeURIComponent(query)}`);
          if (!response.ok) {
            throw new Error('서버 응답 오류');
          }
          const data = await response.json();
          movies = data.results;
          currentPage = 1;
          renderMovies();
          renderPagination();
        } catch (error) {
          console.error('검색 실패:', error);
          alert('검색 중 문제가 발생했습니다.');
        }
      });
    }

    function renderMovies() {
      resultDiv.innerHTML = '';

      if (movies.length === 0) {
        resultDiv.innerHTML = '<p>검색 결과가 없습니다.</p>';
        return;
      }

      const startIndex = (currentPage - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;
      const pageItems = movies.slice(startIndex, endIndex);

      pageItems.forEach(movie => {
        const movieDiv = document.createElement('div');
        movieDiv.className = 'movie-card';
        movieDiv.innerHTML = `
          ${movie.poster_path 
            ? `<img src="https://image.tmdb.org/t/p/w200${movie.poster_path}" alt="${movie.title}">`
            : `<div style="width:200px; height:300px; background-color:lightgray; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:14px; color:#666;">No Image</div>`
          }
          <h3>${movie.title}</h3>
        `;
        resultDiv.appendChild(movieDiv);
      });
    }

    function renderPagination() {
      const totalPages = Math.ceil(movies.length / itemsPerPage);
      const paginationDiv = document.createElement('div');
      paginationDiv.style.textAlign = 'center';
      paginationDiv.style.marginTop = '10px';

      const prevButton = document.createElement('button');
      prevButton.textContent = '이전';
      prevButton.disabled = currentPage === 1;
      prevButton.style.margin = '0 5px';
      prevButton.addEventListener('click', () => {
        if (currentPage > 1) {
          currentPage--;
          renderMovies();
          renderPagination();
        }
      });

      const pageInfo = document.createElement('span');
      pageInfo.textContent = `${currentPage} / ${totalPages}`;
      pageInfo.style.margin = '0 10px';

      const nextButton = document.createElement('button');
      nextButton.textContent = '다음';
      nextButton.disabled = currentPage === totalPages;
      nextButton.style.margin = '0 5px';
      nextButton.addEventListener('click', () => {
        if (currentPage < totalPages) {
          currentPage++;
          renderMovies();
          renderPagination();
        }
      });

      paginationDiv.appendChild(prevButton);
      paginationDiv.appendChild(pageInfo);
      paginationDiv.appendChild(nextButton);

      resultDiv.appendChild(paginationDiv);
    }
  });